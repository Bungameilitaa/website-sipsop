package comp.finalproject.admin.controller;

import comp.finalproject.admin.entity.Radio;
import comp.finalproject.admin.entity.Tv;
import comp.finalproject.admin.repository.RadioRepository;
import comp.finalproject.admin.repository.TvRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class RadioController {

    @Autowired
    private RadioRepository radioRepository;

    // handler methods go here...

    @RequestMapping("/radio")
    public  String radiopage(Model model){
        List<Radio>listradio=radioRepository.findAll();
        model.addAttribute("listradio",listradio);
        return "Radio";
    }

    @RequestMapping("/newradio")
    public String shownewradio(Model model){
        Radio radio=new Radio();
        model.addAttribute("radio",radio);

        /*List<String> listdurasi = Arrays.asList("30 detik", "60 detik");
        model.addAttribute("listdurasi", listdurasi);

        List<String> listkategori = Arrays.asList("day time", "prime time");
        model.addAttribute("listkategori", listkategori);*/

        return "form_new_radio";
    }
    @RequestMapping(value = "/saveradio", method = RequestMethod.POST)
    public String save(@ModelAttribute("radio") Radio radio) {
        radioRepository.save(radio);

        return "redirect:/radio";
    }

    @RequestMapping("/editradio/{id}")
    public ModelAndView showEditFormradio(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("form_edit_radio");
        Radio radio=radioRepository.findById(id);
        mav.addObject("radio", radio);

        return mav;
    }
    @RequestMapping(value = "/updateradio", method = RequestMethod.POST)
    public String updateradio(@ModelAttribute("radio") Radio radio) {

        radioRepository.save(radio);

        return "redirect:/radio";
    }

    @RequestMapping("/deleteradio/{id}")
    public String deleteradio(@PathVariable(name = "id") long id) {
        radioRepository.deleteById(id);

        return "redirect:/radio";
    }
}
