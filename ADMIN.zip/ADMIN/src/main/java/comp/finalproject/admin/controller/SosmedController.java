package comp.finalproject.admin.controller;

import comp.finalproject.admin.entity.Radio;
import comp.finalproject.admin.entity.Sosmed;
import comp.finalproject.admin.repository.RadioRepository;
import comp.finalproject.admin.repository.SosmedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.Arrays;
import java.util.List;

@Controller
public class SosmedController {

    @Autowired
    private SosmedRepository sosmedRepository;
    // handler methods go here...

    @RequestMapping("/sosmed")
    public  String sosmedpage(Model model){
        List<Sosmed>listsosmed=sosmedRepository.findAll();
        model.addAttribute("listsosmed",listsosmed);
        return "Sosmed";
    }

    @RequestMapping("/newsosmed")
    public String shownewsosmed(Model model){
        Sosmed sosmed=new Sosmed();
        model.addAttribute("sosmed",sosmed);

        List<String> listinfluencer = Arrays.asList("Nano", "Micro","Macro","Mega");
        model.addAttribute("listinfluencer", listinfluencer);


        return "form_new_sosmed";
    }
    @RequestMapping(value = "/savesosmed", method = RequestMethod.POST)
    public String save(@ModelAttribute("sosmed") Sosmed sosmed) {
        sosmedRepository.save(sosmed);

        return "redirect:/sosmed";
    }

    @RequestMapping("/editsosmed/{id}")
    public ModelAndView showEditFormsosmed(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("form_edit_sosmed");
        Sosmed sosmed=sosmedRepository.findById(id);
        mav.addObject("sosmed", sosmed);


        List<String> listinfluencer = Arrays.asList("Nano", "Micro","Macro","Mega");
        mav.addObject("listinfluencer", listinfluencer);
        /*mav.addAttribute("listinfluencer", listinfluencer);*/
        return mav;
    }
    @RequestMapping(value = "/updatesosmed", method = RequestMethod.POST)
    public String updatesosmed(@ModelAttribute("sosmed") Sosmed sosmed) {

        sosmedRepository.save(sosmed);

        return "redirect:/sosmed";
    }

    @RequestMapping("/deletesosmed/{id}")
    public String deletesosmed(@PathVariable(name = "id") long id) {
        sosmedRepository.deleteById(id);

        return "redirect:/sosmed";
    }
}
