package comp.finalproject.admin.controller;


import comp.finalproject.admin.entity.Tv;
import comp.finalproject.admin.repository.TvRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import java.util.Arrays;
import java.util.List;
@Controller
public class TvController {

    @Autowired
    private TvRepository tvRepository;

    // handler methods go here...

    @RequestMapping("/tv")
    public  String tvhimepage(Model model){
        List<Tv> listTv=tvRepository.findAll();
        model.addAttribute("listTv",listTv);
        return "Tv";
    }
    /*@RequestMapping("/items")
    public String viewHomePage(Model model) {
        List<Budget> listItem = budgetRepository.findAll();
        model.addAttribute("listItem", listItem);
        return "items2";
    }*/

    @RequestMapping("/newTV")
    public String shownewTV(Model model){


        Tv tv=new Tv();
        model.addAttribute("tv",tv);

        /*List<String> listdurasi = Arrays.asList("30 detik", "60 detik");
        model.addAttribute("listdurasi", listdurasi);

        List<String> listkategori = Arrays.asList("day time", "prime time");
        model.addAttribute("listkategori", listkategori);*/

        return "form_new_tv";
    }
    @RequestMapping(value = "/savetv", method = RequestMethod.POST)
    public String save(@ModelAttribute("tv") Tv tv) {
        tvRepository.save(tv);

        return "redirect:/tv";
    }

    @RequestMapping("/editTV/{id}")
    public ModelAndView showEditForm(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("form_edit_tv");
        Tv tv=tvRepository.findById(id);
        mav.addObject("tv", tv);

        return mav;
    }
    @RequestMapping(value = "/updateTV", method = RequestMethod.POST)
    public String update(@ModelAttribute("tv") Tv tv) {

        tvRepository.save(tv);

        return "redirect:/tv";
    }

    @RequestMapping("/deleteTV/{id}")
    public String delete(@PathVariable(name = "id") long id) {
        tvRepository.deleteById(id);

        return "redirect:/tv";
    }
    /*@RequestMapping("/newitem")
    public String showNewForm(Model model) {
        Budget budget = new Budget();
        model.addAttribute("item", budget);

        return "itemsnew";
    }*/

   /* @RequestMapping(value = "/saveitem", method = RequestMethod.POST)
    public String save(@ModelAttribute("item") Budget item) {
        budgetRepository.save(item);

        return "redirect:/items";
    }

    @RequestMapping("/edititem/{id}")
    public ModelAndView showEditForm(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("itemsedit");
        Budget item = budgetRepository.findById(id);
        mav.addObject("item", item);

        return mav;
    }

    @RequestMapping("/showitem/{id}")
    public ModelAndView showItemForm(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("showitem_form");
        Budget item = budgetRepository.findById(id);
        mav.addObject("item", item);

        return mav;
    }

    @RequestMapping(value = "/updateitem", method = RequestMethod.POST)
    public String update(@ModelAttribute("item") Budget item) {

        budgetRepository.save(item);

        return "redirect:/items";
    }

    @RequestMapping("/deleteitem/{id}")
    public String delete(@PathVariable(name = "id") long id) {
        budgetRepository.deleteById(id);
        return "redirect:/items";
    }*/

}
