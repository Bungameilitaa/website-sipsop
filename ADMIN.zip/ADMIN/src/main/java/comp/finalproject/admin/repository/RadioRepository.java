package comp.finalproject.admin.repository;

import comp.finalproject.admin.entity.Radio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RadioRepository extends JpaRepository<Radio,Long> {
    List<Radio> findAll();

    Radio findById(long id);
}
