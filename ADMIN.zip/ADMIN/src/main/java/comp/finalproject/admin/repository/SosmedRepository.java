package comp.finalproject.admin.repository;

import comp.finalproject.admin.entity.Radio;
import comp.finalproject.admin.entity.Sosmed;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SosmedRepository extends JpaRepository<Sosmed,Long> {
    List<Sosmed> findAll();

    Sosmed findById(long id);
}
