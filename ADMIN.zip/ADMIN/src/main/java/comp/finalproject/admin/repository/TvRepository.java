package comp.finalproject.admin.repository;


import comp.finalproject.admin.entity.Tv;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TvRepository extends JpaRepository<Tv,Long> {
    List<Tv> findAll();

    Tv findById(long id);
}
